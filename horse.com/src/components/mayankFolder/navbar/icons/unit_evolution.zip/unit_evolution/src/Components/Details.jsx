import React from "react";
const Details =()=>{

    return (
        <div>
            
        </div>
    )
}
export default Details;