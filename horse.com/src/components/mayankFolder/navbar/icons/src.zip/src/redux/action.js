export const LOGIN_SUCCESS = "loginSuccess";
export const LOGIN_FAILURE = "loginFailure";
export const LOGOUT = "logout";


export const PRODUCT_LIST_REQUEST = "productListRequest";
export const PRODUCT_LIST_SUCCESS = "productListSuccess";
export const PRODUCT_LIST_FAILURE = "productListFailure";


export const PRODUCT_REQUEST = "productRequest";
export const PRODUCT_SUCCESS = "productSuccess";
export const PRODUCT_FAILURE = "productFailure";